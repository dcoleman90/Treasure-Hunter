package edu.westga.cs6312.midterm.view;

import java.util.Scanner;

import edu.westga.cs6312.midterm.model.GameBoard;

/**
 * This is the TreasureTUI (Text User Interface) class which will allow user
 * interaction with the console
 * 
 * @author Drew Coleman
 * @version 02/15/2018
 *
 */
public class TreasureTUI {
	private GameBoard treasureHunt;
	private Scanner scan;

	/**
	 * This is the constructor it accepts a GameBoard variable and initializes the
	 * instance variables
	 * 
	 * @param treasureHunt
	 *            is the accepted GameBoard variable
	 */
	public TreasureTUI(GameBoard treasureHunt) {
		if (treasureHunt == null) {
			throw new IllegalArgumentException("The GameBoard cannot be null");
		}
		this.treasureHunt = treasureHunt;
		this.scan = new Scanner(System.in);
	}

	/**
	 * This method runs the class and calls private methods to prompt and guide the
	 * user
	 */
	public void run() {
		System.out.println(this.greeting());
		this.menu();
	}

	private String greeting() {
		return "Welcome to the Treasure Hunt Application";

	}

	private int getUserInt(String message) {
		if (message == null) {
			throw new IllegalArgumentException("The String message cannot be null");
		}
		System.out.println("\t 1- Describe the Room\n\t 2- Describe the player\n\t"
				+ " 3- Describe the Game Board\n\t 4- Move Player\n\t 5- Open Treasure\n\t 9- Quit\n Please enter your selection:");
		message = this.scan.nextLine();
		int selection = Integer.parseInt(message);
		return selection;
	}

	private void menu() {
		String message = "";
		int selection;
		do {
			selection = this.getUserInt(message);
			switch (selection) {
				case 1:
					this.describeRoom();
					break;
	
				case 2:
					this.describePlayer();
					break;
	
				case 3:
					this.describeGameBoard();
					break;
	
				case 4:
					this.movePlayer();
					break;
	
				case 5:
					this.openChest();
					break;
	
				case 9:
					this.goodbye();
					break;
	
				default:
					System.out.println("This is not a valid selection. Please try again");
			}
		} while (selection != 9);
	}

	private void describeRoom() {
		System.out.println(this.treasureHunt.getCurrentRoom().toString());
	}

	private void describePlayer() {
		System.out.println(this.treasureHunt.getPlayer().toString());
	}

	private void describeGameBoard() {
		System.out.println(this.treasureHunt.toString());
	}

	private void movePlayer() {
		int selection;
		do {
			System.out.println("\t1- Left\n\t2- Right");
			String message = this.scan.nextLine();
			selection = Integer.parseInt(message);

			switch (selection) {
				case 1:
					this.playerMoveLeft();
					break;
	
				case 2:
					this.playerMoveRight();
					break;
	
				default:
					System.out.println("This is not a valid direction");
			}
		} while (selection != 1 && selection != 2);
	}

	private void playerMoveLeft() {
		this.treasureHunt.moveLeft();
		this.describePlayer();
		System.out.print(" inside ");
		this.describeRoom();
	}

	private void playerMoveRight() {
		this.treasureHunt.moveRight();
		this.describePlayer();
		System.out.print(" inside ");
		this.describeRoom();
	}

	private void openChest() {
		int moneyTransfered = 0;
		if (this.treasureHunt.getCurrentRoom().getTreasure() == null) {
			System.out.println("The room contains no treasure");
		} else if (this.treasureHunt.getPlayer().getMoneyRemaining() >= 50) {
			this.treasureHunt.getPlayer().deductMoney(50);
			moneyTransfered = this.treasureHunt.getCurrentRoom().getTreasure().deliverPayment();
			this.treasureHunt.getPlayer().acceptMoney(moneyTransfered);
			this.describePlayerAndTreasureChest();
		} else {
			this.outOfMoney();
			this.describePlayerAndTreasureChest();
		}
	}

	private void describePlayerAndTreasureChest() {
		String playerAndChestState = this.treasureHunt.getCurrentRoom().getTreasure().toString() + "\n"
				+ this.treasureHunt.getPlayer().toString();
		System.out.println(playerAndChestState);
	}

	private void outOfMoney() {
		System.out.println(
				this.treasureHunt.getPlayer().toString() + " which is not enough money to open the treasure chest");
	}

	private void goodbye() {
		System.out.println("Thank you for looking for treasure with us.\n\t\tGoodBye!");
	}

}
