package edu.westga.cs6312.midterm.testing.Player;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.midterm.model.Player;

class TestPlayerDeductMoney {

	/**
	 * This test will check the deductMoney method by comparing int values using the
	 * getMoneyRemaining method This test will check the default value of 100 after
	 * calling deductMoney(25) which should return 75
	 */
	@Test
	void testDeductMoney25WhichShouldReturn75() {
		Player player1 = new Player();
		player1.deductMoney(25);
		assertEquals(75, player1.getMoneyRemaining());
	}
	
	/**
	 * This test will check the deductMoney method by comparing int values using the
	 * getMoneyRemaining method This test will check the default value of 100 after
	 * calling deductMoney(50) which should return 50
	 */
	@Test
	void testDeductMoney50WhichShouldReturn50() {
		Player player1 = new Player();
		player1.deductMoney(50);
		assertEquals(50, player1.getMoneyRemaining());
	}
	
	/**
	 * This test will check the deductMoney method by comparing int values using the
	 * getMoneyRemaining method This test will check the default value of 100 after
	 * calling deductMoney(75) which should return 25
	 */
	@Test
	void testDeductMoney75WhichShouldReturn25() {
		Player player1 = new Player();
		player1.deductMoney(75);
		assertEquals(25, player1.getMoneyRemaining());
	}
	
	/**
	 * This test will check the deductMoney method by comparing int values using the
	 * getMoneyRemaining method This test will check the default value of 100 after
	 * calling deductMoney(500) which should return -400
	 */
	@Test
	void testDeductMoney500WhichShouldReturnNegitive400() {
		Player player1 = new Player();
		player1.deductMoney(500);
		assertEquals(-400, player1.getMoneyRemaining());
	}
	
}
