package edu.westga.cs6312.midterm.testing.GameBoard;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.midterm.model.GameBoard;

class TestGameBoardWhenMovePlayerRight {

	/**
	 * This test will test the moveRight method by calling it 1 time moving the
	 * player from room 0 to room 1 the test will compare the
	 * getCurrentRoom().getLocation() method to the hard coded value ""
	 */
	@Test
	void testGameBoardMoveRight1TimeReturnRoomAt1() {
		GameBoard dominion = new GameBoard();
		dominion.moveRight();
		assertEquals("Room at [1]", dominion.getCurrentRoom().getLocation());
	}

	/**
	 * This test will test the moveRight method by calling it 5 times moving the
	 * player from room 0 to room 5 the test will compare the
	 * getCurrentRoom().getLocation() method to the hard coded value ""
	 */
	@Test
	void testGameBoardMoveRight5TimesReturnRoomAt5() {
		GameBoard dominion = new GameBoard();
		for (int count = 0; count < 5; count++) {
			dominion.moveRight();
		}
		assertEquals("Room at [5]", dominion.getCurrentRoom().getLocation());
	}

	/**
	 * This test will test the moveRight method by calling it 10 times moving the
	 * player from room 0 to wrap back room 0 the test will compare the
	 * getCurrentRoom().getLocation() method to the hard coded value ""
	 */
	@Test
	void testGameBoardMoveRight10TimesReturnRoomAt0() {
		GameBoard dominion = new GameBoard();
		for (int count = 0; count < 10; count++) {
			dominion.moveRight();
		}
		assertEquals("Room at [0]", dominion.getCurrentRoom().getLocation());
	}
	
	/**
	 * This test will test the moveRight method by calling it 12 times moving the
	 * player from room 0 to wrap back room 2 the test will compare the
	 * getCurrentRoom().getLocation() method to the hard coded value ""
	 */
	@Test
	void testGameBoardMoveRight12TimesReturnRoomAt2() {
		GameBoard dominion = new GameBoard();
		for (int count = 0; count < 12; count++) {
			dominion.moveRight();
		}
		assertEquals("Room at [2]", dominion.getCurrentRoom().getLocation());
	}
}
