package edu.westga.cs6312.midterm.testing.Room;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Random;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.midterm.model.Room;

class TestRoomGetLocation {
	
	/**
	 * This test will check the method getLocation with the idNumber set at 1
	 * It return a String and will be compared to a hard coded value
	 */
	@Test
	void testGetLocationWithIdSetAt1() {
		Room adventureRoom = new Room(1, new Random());
		assertEquals("Room at [1]", adventureRoom.getLocation());
	}
	
	/**
	 * This test will check the method getLocation with the idNumber set at 3
	 * It return a String and will be compared to a hard coded value
	 */
	@Test
	void testGetLocationWithIdSetAt3() {
		Room adventureRoom = new Room(3, new Random());
		assertEquals("Room at [3]", adventureRoom.getLocation());
	}
	
	/**
	 * This test will check the method getLocation with the idNumber set at 7
	 * It return a String and will be compared to a hard coded value
	 */
	@Test
	void testGetLocationWithIdSetAt7() {
		Room adventureRoom = new Room(7, new Random());
		assertEquals("Room at [7]", adventureRoom.getLocation());
	}

	/**
	 * This test will check the method getLocation with the idNumber set at 10
	 * It return a String and will be compared to a hard coded value
	 */
	@Test
	void testGetLocationWithIdSetAt10() {
		Room adventureRoom = new Room(10, new Random());
		assertEquals("Room at [10]", adventureRoom.getLocation());
	}
	
	/**
	 * This test will check the method getLocation with the idNumber set at 100
	 * It return a String and will be compared to a hard coded value
	 */
	@Test
	void testGetLocationWithIdSetAt100() {
		Room adventureRoom = new Room(100, new Random());
		assertEquals("Room at [100]", adventureRoom.getLocation());
	}
}
