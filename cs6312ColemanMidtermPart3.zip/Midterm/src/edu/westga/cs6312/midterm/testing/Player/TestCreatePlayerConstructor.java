package edu.westga.cs6312.midterm.testing.Player;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.midterm.model.Player;

class TestCreatePlayerConstructor {

	/**
	 * This test will test the constructor insuring it returns with a new player with 100 money units
	 * The test will compare the player's toString methods
	 */
	@Test
	void testPlayerConstructorUsingDefaultValuesShouldReturnWith100() {
		Player player1 = new Player();
		assertEquals("The player has 100 money units remaining", player1.toString());
	}
	
	/**
	 * This test will test the constructor insuring it returns with two new players and insure that their toString
	 * values are the same insuring that the constructor remains consistent
	 */
	@Test
	void testPlayerConstructorUsing2PlayersShouldReturnEqual() {
		Player player1 = new Player();
		Player player2 = new Player();
		assertEquals(player2.toString(), player1.toString());
	}


}
