package edu.westga.cs6312.midterm.testing.Player;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.midterm.model.Player;

class TestPlayerAcceptMoney {

	/**
	 * This test will check the acceptMoney method by comparing int values using the
	 * getMoneyRemaining method This test will check the default value of 100 after
	 * calling acceptMoney(25) which should return 125
	 */
	@Test
	void testAcceptMoney25WhichShouldReturn125() {
		Player player1 = new Player();
		player1.acceptMoney(25);
		assertEquals(125, player1.getMoneyRemaining());
	}

	/**
	 * This test will check the acceptMoney method by comparing int values using the
	 * getMoneyRemaining method This test will check the default value of 100 after
	 * calling acceptMoney(50) which should return 150
	 */
	@Test
	void testAcceptMoney50WhichShouldReturn150() {
		Player player1 = new Player();
		player1.acceptMoney(50);
		assertEquals(150, player1.getMoneyRemaining());
	}

	/**
	 * This test will check the acceptMoney method by comparing int values using the
	 * getMoneyRemaining method This test will check the default value of 100 after
	 * calling acceptMoney(75) which should return 175
	 */
	@Test
	void testAcceptMoney75WhichShouldReturn75() {
		Player player1 = new Player();
		player1.acceptMoney(75);
		assertEquals(175, player1.getMoneyRemaining());
	}

	/**
	 * This test will check the acceptMoney method by comparing int values using the
	 * getMoneyRemaining method This test will check the default value of 100 after
	 * calling acceptMoney(500) which should return 600
	 */
	@Test
	void testAcceptMoney500WhichReturns600() {
		Player player1 = new Player();
		player1.acceptMoney(500);
		assertEquals(600, player1.getMoneyRemaining());
	}
}
