package edu.westga.cs6312.midterm.testing.GameBoard;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.midterm.model.GameBoard;

class TestGameBoardWhenMovePlayerLeft {


	/**
	 * This test will test the moveLeft method by calling it 1 time moving the
	 * player from room 0 to room 9 the test will compare the
	 * getCurrentRoom().getLocation() method to the hard coded value ""
	 */
	@Test
	void testGameBoardmoveLeft1TimeReturnRoomAt1() {
		GameBoard dominion = new GameBoard();
		dominion.moveLeft();
		assertEquals("Room at [9]", dominion.getCurrentRoom().getLocation());
	}

	/**
	 * This test will test the moveLeft method by calling it 5 times moving the
	 * player from room 0 to room 5 the test will compare the
	 * getCurrentRoom().getLocation() method to the hard coded value ""
	 */
	@Test
	void testGameBoardmoveLeft5TimesReturnRoomAt5() {
		GameBoard dominion = new GameBoard();
		for (int count = 0; count < 5; count++) {
			dominion.moveLeft();
		}
		assertEquals("Room at [5]", dominion.getCurrentRoom().getLocation());
	}

	/**
	 * This test will test the moveLeft method by calling it 10 times moving the
	 * player from room 0 to wrap back room 0 the test will compare the
	 * getCurrentRoom().getLocation() method to the hard coded value ""
	 */
	@Test
	void testGameBoardmoveLeft10TimesReturnRoomAt0() {
		GameBoard dominion = new GameBoard();
		for (int count = 0; count < 10; count++) {
			dominion.moveLeft();
		}
		assertEquals("Room at [0]", dominion.getCurrentRoom().getLocation());
	}
	
	/**
	 * This test will test the moveLeft method by calling it 12 times moving the
	 * player from room 0 to wrap back room 8 the test will compare the
	 * getCurrentRoom().getLocation() method to the hard coded value ""
	 */
	@Test
	void testGameBoardmoveLeft12TimesReturnRoomAt2() {
		GameBoard dominion = new GameBoard();
		for (int count = 0; count < 12; count++) {
			dominion.moveLeft();
		}
		assertEquals("Room at [8]", dominion.getCurrentRoom().getLocation());
	}
}
