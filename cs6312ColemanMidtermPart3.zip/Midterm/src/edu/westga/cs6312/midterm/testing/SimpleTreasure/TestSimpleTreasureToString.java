package edu.westga.cs6312.midterm.testing.SimpleTreasure;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.midterm.model.SimpleTreasure;

class TestSimpleTreasureToString {

	/**
	 * This test will insure that a SimpleTreasure object can successfully construct
	 * and then execute the toString method by comparing the toString method with
	 * the expected value of "A simple Treasure chest with 75 money units inside"
	 */
	@Test
	void testSimpleTreasureToStringMethod() {
		SimpleTreasure lockBox = new SimpleTreasure();
		assertEquals("A Simple Treasure chest with 75 money units inside", lockBox.toString());
	}

	/**
	 * This test will insure that a SimpleTreasure object can successfully construct
	 * and then execute the toString method After calling the removeMoney method by
	 * comparing the toString method with the expected value of "A simple Treasure
	 * chest with 25 money units inside"
	 */
	@Test
	void testSimpleTreasureToStringMethodAfterCallingRemoveMoney50() {
		SimpleTreasure lockBox = new SimpleTreasure();
		lockBox.removeMoney(50);
		assertEquals("A Simple Treasure chest with 25 money units inside", lockBox.toString());
	}

	/**
	 * This test will insure that a SimpleTreasure object can successfully construct
	 * and then execute the toString method After calling the removeMoney method
	 * with deliverPayment as the variable it will be tested by comparing the
	 * toString method with the expected value of "A simple Treasure chest with 0
	 * money units inside"
	 */
	@Test
	void testSimpleTreasureToStringMethodAfterCallingDeliverPayment() {
		SimpleTreasure lockBox = new SimpleTreasure();
		lockBox.removeMoney(lockBox.deliverPayment());
		assertEquals("A Simple Treasure chest with 0 money units inside", lockBox.toString());
	}

	/**
	 * This test will insure that a SimpleTreasure object can successfully construct
	 * and then execute the toString method by comparing the toString method with
	 * the another SimpleTreasure object
	 * 
	 */
	@Test
	void testSimpleTreasureToStringMethodByComparingTwoSimpleTreasures() {
		SimpleTreasure lockBox = new SimpleTreasure();
		SimpleTreasure simpleBox = new SimpleTreasure();
		assertEquals(simpleBox.toString(), lockBox.toString());
	}
}
