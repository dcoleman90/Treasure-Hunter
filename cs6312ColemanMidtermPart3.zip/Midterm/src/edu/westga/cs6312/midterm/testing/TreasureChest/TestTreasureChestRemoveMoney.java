package edu.westga.cs6312.midterm.testing.TreasureChest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.midterm.model.SimpleTreasure;
import edu.westga.cs6312.midterm.model.TreasureChest;

class TestTreasureChestRemoveMoney {

	/**
	 * This test will call a SimpleTreasure object then use the removeMoney method
	 * to deduct 50 from the standard 75 the SimpleTreasure holds leaving 25
	 * remaining. This will be checked by calling the getMoneyRemaining method
	 */
	@Test
	void testTreasureChestRemoveMoney25FromSimpleTreasure25Remains() {
		TreasureChest bigChest = new SimpleTreasure();
		bigChest.removeMoney(50);
		assertEquals(25, bigChest.getMoneyRemaining());
	}

	/**
	 * This test will call a SimpleTreasure object then use the removeMoney method
	 * to deduct 1 from the standard 75 the SimpleTreasure holds leaving 74
	 * remaining. This will be checked by calling the getMoneyRemaining method
	 */
	@Test
	void testTreasureChestRemoveMoney1FromSimpleTreasure74Remains() {
		TreasureChest bigChest = new SimpleTreasure();
		bigChest.removeMoney(1);
		assertEquals(74, bigChest.getMoneyRemaining());
	}
	
	/**
	 * This test will call a SimpleTreasure object then use the removeMoney method
	 * to deduct 75 from the standard 75 the SimpleTreasure holds leaving 0
	 * remaining. This will be checked by calling the getMoneyRemaining method
	 */
	@Test
	void testTreasureChestRemoveMoney75FromSimpleTreasure0Remains() {
		TreasureChest bigChest = new SimpleTreasure();
		bigChest.removeMoney(75);
		assertEquals(0, bigChest.getMoneyRemaining());
	}
	
	/**
	 * This test will call a SimpleTreasure object then use the removeMoney method
	 * to deduct 0 from the standard 75 the SimpleTreasure holds leaving 75
	 * remaining. This will be checked by calling the getMoneyRemaining method
	 */
	@Test
	void testTreasureChestRemoveMoney0FromSimpleTreasure75Remains() {
		TreasureChest bigChest = new SimpleTreasure();
		bigChest.removeMoney(0);
		assertEquals(75, bigChest.getMoneyRemaining());
	}
}
