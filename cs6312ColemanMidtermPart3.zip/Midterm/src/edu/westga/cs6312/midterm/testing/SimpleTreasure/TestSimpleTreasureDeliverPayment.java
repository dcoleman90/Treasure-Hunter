package edu.westga.cs6312.midterm.testing.SimpleTreasure;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.midterm.model.SimpleTreasure;

class TestSimpleTreasureDeliverPayment {

	/**
	 * This test will check the default constructor value 75 and insure that the
	 * deliverPayment method returns the same value
	 */
	@Test
	void testSimpleTreasureDefault75InsureDelieverPaymentReturns75() {
		SimpleTreasure lockBox = new SimpleTreasure();
		assertEquals(75, lockBox.deliverPayment());
	}

	/**
	 * This test will check the default constructor value 75 and insures after calling removeMoney(50) the
	 * deliverPayment method returns the expected value 25
	 */
	@Test
	void testSimpleTreasureDefault75AfterCallingRemoveMoney50DelieverPaymentReturns25() {
		SimpleTreasure lockBox = new SimpleTreasure();
		lockBox.removeMoney(50);
		assertEquals(25, lockBox.deliverPayment());
	}

	/**
	 * This test will check the default constructor value 75 and insures after calling removeMoney(25) the
	 * deliverPayment method returns the expected value 50
	 */
	@Test
	void testSimpleTreasureDefault75AfterCallingRemoveMoney25DelieverPaymentReturns50() {
		SimpleTreasure lockBox = new SimpleTreasure();
		lockBox.removeMoney(25);
		assertEquals(50, lockBox.deliverPayment());
	}
	
	/**
	 * This test will check the default constructor value 75 and insures after calling removeMoney(75) the
	 * deliverPayment method returns the expected value 0
	 */
	@Test
	void testSimpleTreasureDefault75AfterCallingRemoveMoney75DelieverPaymentReturns0() {
		SimpleTreasure lockBox = new SimpleTreasure();
		lockBox.removeMoney(75);
		assertEquals(0, lockBox.deliverPayment());
	}
}
