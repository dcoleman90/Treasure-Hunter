package edu.westga.cs6312.midterm.testing.RandomTreasure;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Random;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.midterm.model.RandomTreasure;

class TestRandomTreasureToString {

	/**
	 * This test will test RandomTreasure constructor and toString method by
	 * comparing a hard coded expected result with the actual output "A Random
	 * Treasure chest with 100 money units inside"
	 */
	@Test
	void testRandomTestToStringMethod() {
		RandomTreasure mysteryBox = new RandomTreasure(new Random());
		assertEquals("A Random Treasure chest with 100 money units inside", mysteryBox.toString());
	}
	
	/**
	 * This test will test RandomTreasure constructor and toString method by
	 * comparing a two RandomTreasure objects and insuring they remain consistent
	 */
	@Test
	void testRandomTestToStringMethodAgainstAnotherRandomTreasure() {
		RandomTreasure mysteryBox = new RandomTreasure(new Random());
		RandomTreasure questionBox = new RandomTreasure(new Random());
		assertEquals(questionBox.toString(), mysteryBox.toString());
	}

}
