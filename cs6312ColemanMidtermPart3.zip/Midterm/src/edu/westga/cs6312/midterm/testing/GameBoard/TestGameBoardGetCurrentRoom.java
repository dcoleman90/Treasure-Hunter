package edu.westga.cs6312.midterm.testing.GameBoard;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.midterm.model.GameBoard;

class TestGameBoardGetCurrentRoom {

	/**
	 * This test will return the CurrentRoom the player is located inside the
	 * GameBoard it will test risk.getCurrentRoom().getLocation() which will return
	 * a String value of "Room at [0]"
	 */
	@Test
	void testCurrentRoomMethodShouldReturnLocationRoomAt0() {
		GameBoard risk = new GameBoard();
		assertEquals("Room at [0]", risk.getCurrentRoom().getLocation());
	}

	/**
	 * This test will return the CurrentRoom the player is located inside the
	 * GameBoard it will test risk.getCurrentRoom().getLocation() against
	 * chess.getCurrentRoom().getLocation() both methods should return a String
	 * value of "Room at [0]"
	 */
	@Test
	void testCurrentRoomMethodAgainstAnotherCurrentRoom() {
		GameBoard risk = new GameBoard();
		GameBoard chess = new GameBoard();
		assertEquals(chess.getCurrentRoom().getLocation(), risk.getCurrentRoom().getLocation());
	}

}
