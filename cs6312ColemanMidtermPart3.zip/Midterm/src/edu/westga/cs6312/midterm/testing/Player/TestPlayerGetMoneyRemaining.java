package edu.westga.cs6312.midterm.testing.Player;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.midterm.model.Player;

class TestPlayerGetMoneyRemaining {

	/**
	 * This test will check the getMoneyRemaining method by comparing int values
	 * This test will check the default value of 100
	 */
	@Test
	void testGetMoneyRemainingUsingTheDefaultValueOf100() {
		Player player1 = new Player();
		assertEquals(100, player1.getMoneyRemaining());
	}

	/**
	 * This test will check the getMoneyRemaining method by comparing int values
	 * This test will check the default value of 100 by comparing two different
	 * players and insuring the default values are equal
	 */
	@Test
	void testGetMoneyRemainingByComparingTwoPlayersOf100() {
		Player player1 = new Player();
		Player player2 = new Player();
		assertEquals(player1.getMoneyRemaining(), player2.getMoneyRemaining());
	}

}
