package edu.westga.cs6312.midterm.testing.GameBoard;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import edu.westga.cs6312.midterm.model.GameBoard;

class TestGameBoardGetPlayer {

	/**
	 * This test will check the getPlayer method and insure that it returns the
	 * correct amount of money the player has in this case 100
	 */
	@Test
	void testGetPlayerMethodShouldReturnWith100() {
		GameBoard catan = new GameBoard();
		assertEquals(100, catan.getPlayer().getMoneyRemaining());
	}

	/**
	 * This test will check the getPlayer method and insure that it returns the
	 * correct amount of money the player has in this case 100 This test will
	 * compare two different GameBoards
	 */
	@Test
	void testGetPlayerMethodTestingTwoGameBoardsShouldReturnEqual() {
		GameBoard catan = new GameBoard();
		GameBoard monopoly = new GameBoard();
		assertEquals(monopoly.getPlayer().getMoneyRemaining(), catan.getPlayer().getMoneyRemaining());
	}

}
