/**
 * 
 */
package edu.westga.cs6312.midterm.controller;

import edu.westga.cs6312.midterm.model.GameBoard;
import edu.westga.cs6312.midterm.view.TreasureTUI;

/**
 * This is the TreasureDriver class it contains the main Method and calls the
 * TreasureTUI run method
 * 
 * @author Drew Coleman
 * @version 02/15/2018
 *
 */
public class TreasureDriver {

	/**This is the main method and will run the TreasureTUI 
	 * @param args is the main argument
	 */
	public static void main(String[] args) {
		GameBoard treasureHunt = new GameBoard();
		TreasureTUI gameTime = new TreasureTUI(treasureHunt);
		gameTime.run();

	}

}
