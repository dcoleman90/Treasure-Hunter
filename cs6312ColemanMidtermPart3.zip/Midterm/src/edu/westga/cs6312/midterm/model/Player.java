/**
 * 
 */
package edu.westga.cs6312.midterm.model;

/**
 * This is the player class it will build players and give them starting value
 * of gold
 * 
 * @author Drew Coleman
 * @version 02/14/2018
 *
 */
public class Player {

	private int money;

	/**
	 * This is the default constructor which sets the players money value at 100
	 */
	public Player() {
		this.money = 100;
	}

	/**
	 * This method returns the amount of money remaining
	 * 
	 * @return this.money which is amount of money the player has
	 */
	public int getMoneyRemaining() {
		return this.money;
	}

	/**
	 * This method removes the accepted int variable from instance variable
	 * 
	 * @param moneyLost
	 *            - is the money removed from this.money.
	 */
	public void deductMoney(int moneyLost) {
		if (moneyLost < 0) {
			throw new IllegalArgumentException("The money lost cannot be negative values");
		}
		this.money = this.money - moneyLost;
	}

	/**
	 * This method adds the accepted int variable to the instance variable
	 * 
	 * @param moneyGained
	 *            - is the money added to this.money
	 * Precondition moneyGained cannot be negative 
	 * Postcondition moneyGained is added to this.money
	 */
	public void acceptMoney(int moneyGained) {
		if (moneyGained < 0) {
			throw new IllegalArgumentException("The money gained cannot be negative values");
		}
		this.money = this.money + moneyGained;
	}

	/**
	 * This method returns a string representation of the class
	 * 
	 * @return a string representation of the player "The player has " + this.money
	 *         + " money units remaining"
	 */
	public String toString() {
		return "The player has " + this.money + " money units remaining";
	}
}
