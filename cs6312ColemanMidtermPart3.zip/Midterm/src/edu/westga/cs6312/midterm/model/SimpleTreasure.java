package edu.westga.cs6312.midterm.model;

/**
 * \ This method is a subClass of TreasureChest and will build simple treasure
 * chests
 * 
 * @author Drew Coleman
 * @version 02/14/2018
 *
 */
public class SimpleTreasure extends TreasureChest {

	/**
	 * This method is the constructor which sets the value of the TreasureChest to
	 * 75
	 */
	public SimpleTreasure() {
		super(75);
	}

	/**
	 * This method overrides the superclass (TreasureChest) method and returns an
	 * int value equal to the TreasureChest instance variable by using
	 * getMoneyRemaining
	 */
	@Override
	public int deliverPayment() {
		int emptyTreasure = this.getMoneyRemaining();
		super.removeMoney(emptyTreasure);
		return emptyTreasure;
	}
	
	/**
	 * This method will return a string representation of the SimpleTreasure object
	 * 
	 * @return "A simple Treasure chest with " + this.getMoneyRemaining() +  " money units inside"
	 */
	public String toString() {
		return "A Simple " + super.toString();
	}

}
