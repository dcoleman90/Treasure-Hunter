package edu.westga.cs6312.midterm.model;

import java.util.Random;

/**
 * This is the GameBoard class it will build a GameBoard of 10 Rooms it will
 * keep track of the Game and player stats
 * 
 * @author Drew Coleman
 * @version 02/15/2018
 *
 */
public class GameBoard {
	private Room[] gameBoardRooms = new Room[10];
	private Random rand = new Random();
	private Player player1 = new Player();
	private int roomTracker;

	/**
	 * This is the Constructor it is used to initialize Random then sets the board
	 * for play
	 */
	public GameBoard() {
		this.rand = new Random();
		this.setupBoard();
	}

	private void setupBoard() {
		this.player1 = new Player();
		this.gameBoardRooms = new Room[10];
		for (int count = 0; count < 10; count++) {
			this.gameBoardRooms[count] = new Room(count, this.rand);
		}
		this.roomTracker = 0;
	}

	/**
	 * This method returns the instance variable this.player1
	 * 
	 * @return this.player1
	 */
	public Player getPlayer() {
		return this.player1;
	}

	/**
	 * This method returns the location in the Room Array that the player is located
	 * 
	 * @return this.gameBoardRooms[this.roomTracker];
	 */
	public Room getCurrentRoom() {
		return this.gameBoardRooms[this.roomTracker];
	}

	/**
	 * This method gives a String representation of the GameBoard class
	 * 
	 * @return gameState + "\n" + playerLocation
	 * 
	 *         gameState is a list of all the rooms and possible treasure within
	 *         them in the GameBoard array playerLocation is a description of the
	 *         player's funds and the room they are in
	 */
	public String toString() {
		String gameState = "";
		String playerLocation = "";
		for (Room roomDescription : this.gameBoardRooms) {
			gameState += roomDescription.toString() + "\n";
		}
		playerLocation = "Player with " + this.player1.getMoneyRemaining();
		playerLocation += " and is located in " + this.gameBoardRooms[this.roomTracker];
		playerLocation += this.gameBoardRooms[this.roomTracker].getTreasure();
		return gameState + "\n" + playerLocation;
	}

	/**
	 * This method increases the roomTracker by 1 causing the player to move "right"
	 * and causes it to "wrap" if it goes over 9 (which is the size of the
	 * GameBoard)
	 */
	public void moveRight() {
		this.roomTracker = this.roomTracker + 1;
		if (this.roomTracker > 9) {
			this.roomTracker = 0;
		}
	}

	/**
	 * This method decreases the roomTracker by 1 causing the player to move "left"
	 * and causes it to "wrap" if it goes under 0 back to 9 (which is the size of the
	 * GameBoard)
	 */
	public void moveLeft() {
		this.roomTracker = this.roomTracker - 1;
		if (this.roomTracker < 0) {
			this.roomTracker = 9;
		}
	}
}
