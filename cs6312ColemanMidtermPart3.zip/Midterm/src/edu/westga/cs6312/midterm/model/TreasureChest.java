/**
 * 
 */
package edu.westga.cs6312.midterm.model;

/**
 * This abstract class stores the int money available inside TreasureChest
 * 
 * @author Drew Coleman
 * @version 02/14/2018
 *
 */
public abstract class TreasureChest {
	private int treasure;

	/**
	 * This is the constructor which initializes the instance variable treasure
	 * 
	 * @param goldInsideChest
	 *            is the accepted int value which is the amount of treasure
	 * 
	 *            Precondition goldInsideChest >= 0; Postcondition TreasureChest is
	 *            filled with treasure
	 */
	public TreasureChest(int goldInsideChest) {
		if (goldInsideChest < 0) {
			throw new IllegalArgumentException("The gold inside the chest cannot be negative");
		}
		this.treasure = goldInsideChest;
	}

	/**
	 * This method will return the value of treasure
	 * 
	 * @return this.treasure
	 */
	public int getMoneyRemaining() {
		return this.treasure;
	}

	/**
	 * This method removes the accepted int value from the instance variable
	 * 
	 * @param moneyRemoved
	 *            is the amount taken from this.treasure moneyRemoved must not be a
	 *            negative number or greater than amount of treasure in the chest
	 *            Precondition moneyRemoved > 0 and moneyRemoved < this.treasure
	 * 
	 *            Postcondition moneyRemoved is the amount taken from this.treasure
	 */
	public void removeMoney(int moneyRemoved) {
		if ((moneyRemoved < 0) || (moneyRemoved > this.treasure)) {
			throw new IllegalArgumentException(
					"The gold removed cannot be negative or greater than the treasure in the chest");
		}
		this.treasure = this.treasure - moneyRemoved;
	}

	/**
	 * This method returns a String object which is a representation of the
	 * TreasureChest Class
	 * 
	 * @return "This Treasure Chest has " + this.treasure + " money units inside"
	 */
	public String toString() {
		return "Treasure chest with " + this.treasure + " money units inside";
	}
	
	/**
	 * This abstract method will insure that other classes implement a way of taking
	 * units from the TreasureChest
	 * 
	 * @return the amount of treasure taken from the TreasureChest
	 */
	public abstract int deliverPayment();

}
