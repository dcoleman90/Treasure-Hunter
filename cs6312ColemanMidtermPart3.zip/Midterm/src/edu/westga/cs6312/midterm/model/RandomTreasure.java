package edu.westga.cs6312.midterm.model;

import java.util.Random;

/**
 * This is the RandomTreasure Class it is a subClass of TreasureChest
 * 
 * @author Drew Coleman
 * @version 02/15/2018
 *
 */
public class RandomTreasure extends TreasureChest {
	private Random rand = new Random();

	/**
	 * This is the constructor which calls the superclass and sets the value at 100
	 * 
	 * @param randomNumber
	 *            is the accepted Random value passed into the constructor
	 */
	public RandomTreasure(Random randomNumber) {
		super(100);
		if (randomNumber == null) {
			throw new IllegalArgumentException(
					"The accepted Random randomNumber cannot be null");
		}
		this.rand = randomNumber;
	}

	/**
	 * This method returns a String representation of the RandomTreausure object
	 * 
	 * @return "A Random " + super.toString();
	 */
	public String toString() {
		return "A Random " + super.toString();
	}

	/**
	 * This method overrides the superclass (TreasureChest) method and returns an
	 * Random int value between 0 and the value of the TreasureChest using the
	 * getMoneyRemaining method
	 */
	@Override
	public int deliverPayment() {
		int treasureGained;
		treasureGained = (this.rand.nextInt(this.getMoneyRemaining()) + 1);
		super.removeMoney(treasureGained);
		return treasureGained;
	}

}
