package edu.westga.cs6312.midterm.model;

import java.util.Random;

/**
 * This is the Room class it contains TreasureChest (might be a null value), an
 * Identification number, and a Random Object
 * 
 * @author Drew Coleman
 * @version 02/14/2018
 *
 */
public class Room {
	private TreasureChest chestOfTreasure;
	private int idNumber;
	private Random randomNumGenerator;

	/**
	 * This is the constructor it accepts Room IdNumbers and RandomVariables and
	 * uses the accepted values to initialize this.idNumber and
	 * this.randomNumGenerator
	 * 
	 * @param idNumber
	 *            is the accepted value for this.idNumber Precondition idNumber
	 *            cannot be negative Postcondition idNumber becomes the value for
	 *            this.idNumber
	 * @param randomVariables
	 *            is the value of the random generator Precondition randomVariables
	 *            cannot be null Postcondition randomVariables is the value of the
	 *            random generator
	 * 
	 */
	public Room(int idNumber, Random randomVariables) {
		if (idNumber < 0) {
			throw new IllegalArgumentException("The Identifying number cannot be negative values");
		}
		if (randomVariables == null) {
			throw new IllegalArgumentException("The Random Number Generator cannot be null");
		}
		this.idNumber = idNumber;
		this.randomNumGenerator = randomVariables;
		this.setupRoom();
	}

	private void setupRoom() {
		int fiftyPercent = this.randomNumGenerator.nextInt(2);
		if (fiftyPercent == 1) {
			this.createTreasure();
		} else {
			this.chestOfTreasure = null;
		}
	}

	private void createTreasure() {
		int fiftyPercent = this.randomNumGenerator.nextInt(2);
		if (fiftyPercent == 1) {
			this.chestOfTreasure = new SimpleTreasure();
		} else {
			this.chestOfTreasure = new RandomTreasure(this.randomNumGenerator);
		}
	}

	/**
	 * this method returns a String value "Room at [" + this.idNumber + "]"; which
	 * Identifies the rooms location
	 * 
	 * @return "Room at [" + this.idNumber + "]";
	 */
	public String getLocation() {
		return "Room at [" + this.idNumber + "]";
	}

	/**
	 * This method returns the TreasureChest object storing the treasure that is
	 * currently in the room
	 * 
	 * @return this.chestOfTreasure which is the instance variable storing the
	 *         treasure in the room
	 */
	public TreasureChest getTreasure() {
		return this.chestOfTreasure;
	}

	/**
	 * This method returns a String value of the Room object
	 * 
	 * @return if this.chestOfTreasure is null this.getLocation() + " with no
	 *         treasure" else return this.getLocation() + " with " +
	 *         this.chestOfTreasure.toString()
	 */
	public String toString() {
		if (this.chestOfTreasure == null) {
			return this.getLocation() + " with no treasure";
		} else {
			return this.getLocation() + " with " + this.chestOfTreasure.toString();
		}
	}

}
